Thank You For Using Our Antivirus, it's free, without any premium functions. Everything is free!
(open open.bat)
(close opening exit.bat)